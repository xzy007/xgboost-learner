/*!
 * Copyright 2014 by Contributors
 * \file param.h
 * \brief training parameters, statistics used to support tree construction.
 * \author Tianqi Chen
 */
#ifndef XGBOOST_TREE_PARAM_H_
#define XGBOOST_TREE_PARAM_H_

#include <vector>
#include <cstring>

namespace xgboost {
namespace tree {

/*! \brief training parameters for regression tree */
struct TrainParam : public dmlc::Parameter<TrainParam> {
  // learning step size for a time
  //训练速率
  float learning_rate;
  // minimum loss change required for a split
  //停止分裂loss_chg的最小值，也就是信息增益没有明显下降了，损失接近0
  float min_split_loss;
  // maximum depth of a tree
  //树的深度
  int max_depth;
  //----- the rest parameters are less important ----
  //下面参数不重要
  // minimum amount of hessian(weight) allowed in a child
  //sum_hess的最小要求，要求节点的二阶梯度必须大于min_child_weight
  float min_child_weight;
  // L2 regularization factor
  //L2正则
  float reg_lambda;
  // L1 regularization factor
  //L1正则
  float reg_alpha;
  // default direction choice
  //missing值的方向
  int default_direction;
  // maximum delta update we can add in weight estimation
  // this parameter can be used to stabilize update
  // default=0 means no constraint on weight delta
  //稳步
  float max_delta_step;
  // whether we want to do subsample   
  //满足subsample采样
  float subsample;
  // whether to subsample columns each split, in each level
  //每次寻找分裂点时，是否都进行随机采样，1则表示没有采样，正常值在(0,1]中
  float colsample_bylevel;
  // whether to subsample columns during tree construction
  //构造树的特征随机采样，1表示没有采样，正常值在(0,1]中
  float colsample_bytree;
  // speed optimization for dense column
  //列的稠密度限制
  float opt_dense_col;
  
  // accuracy of sketch
  //精度的相关量
  float sketch_eps;
  // accuracy of sketch
  //精度的相关量
  float sketch_ratio;
  
  // leaf vector size
  //叶子节点长度
  int size_leaf_vector;
  // option for parallelization
  //并行处理参数
  int parallel_option;
  // option to open cacheline optimization 
  bool cache_opt;
  // number of threads to be used for tree construction,
  // if OpenMP is enabled, if equals 0, use system default
  int nthread;
  // whether to not print info during training.
  bool silent;
  // declare the parameters
  DMLC_DECLARE_PARAMETER(TrainParam) {
    DMLC_DECLARE_FIELD(learning_rate).set_lower_bound(0.0f).set_default(0.3f)
        .describe("Learning rate(step size) of update.");
    DMLC_DECLARE_FIELD(min_split_loss).set_lower_bound(0.0f).set_default(0.0f)
        .describe("Minimum loss reduction required to make a further partition.");
    DMLC_DECLARE_FIELD(max_depth).set_lower_bound(0).set_default(6)
        .describe("Maximum depth of the tree.");
    DMLC_DECLARE_FIELD(min_child_weight).set_lower_bound(0.0f).set_default(1.0f)
        .describe("Minimum sum of instance weight(hessian) needed in a child.");
    DMLC_DECLARE_FIELD(reg_lambda).set_lower_bound(0.0f).set_default(1.0f)
        .describe("L2 regularization on leaf weight");
    DMLC_DECLARE_FIELD(reg_alpha).set_lower_bound(0.0f).set_default(0.0f)
        .describe("L1 regularization on leaf weight");
    DMLC_DECLARE_FIELD(default_direction).set_default(0)
        .add_enum("learn", 0)
        .add_enum("left", 1)
        .add_enum("right", 2)
        .describe("Default direction choice when encountering a missing value");
    DMLC_DECLARE_FIELD(max_delta_step).set_lower_bound(0.0f).set_default(0.0f)
        .describe("Maximum delta step we allow each tree's weight estimate to be. "\
                  "If the value is set to 0, it means there is no constraint");
    DMLC_DECLARE_FIELD(subsample).set_range(0.0f, 1.0f).set_default(1.0f)
        .describe("Row subsample ratio of training instance.");
    DMLC_DECLARE_FIELD(colsample_bylevel).set_range(0.0f, 1.0f).set_default(1.0f)
        .describe("Subsample ratio of columns, resample on each level.");
    DMLC_DECLARE_FIELD(colsample_bytree).set_range(0.0f, 1.0f).set_default(1.0f)
        .describe("Subsample ratio of columns, resample on each tree construction.");
    DMLC_DECLARE_FIELD(opt_dense_col).set_range(0.0f, 1.0f).set_default(1.0f)
        .describe("EXP Param: speed optimization for dense column.");
    DMLC_DECLARE_FIELD(sketch_eps).set_range(0.0f, 1.0f).set_default(0.03f)
        .describe("EXP Param: Sketch accuracy of approximate algorithm.");
    DMLC_DECLARE_FIELD(sketch_ratio).set_lower_bound(0.0f).set_default(2.0f)
        .describe("EXP Param: Sketch accuracy related parameter of approximate algorithm.");
    DMLC_DECLARE_FIELD(size_leaf_vector).set_lower_bound(0).set_default(0)
        .describe("Size of leaf vectors, reserved for vector trees");
    DMLC_DECLARE_FIELD(parallel_option).set_default(0)
        .describe("Different types of parallelization algorithm.");
    DMLC_DECLARE_FIELD(cache_opt).set_default(true)
        .describe("EXP Param: Cache aware optimization.");
    DMLC_DECLARE_FIELD(nthread).set_default(0)
        .describe("Number of threads used for training.");
    DMLC_DECLARE_FIELD(silent).set_default(false)
        .describe("Not print information during trainig.");
    // add alias of parameters
    DMLC_DECLARE_ALIAS(reg_lambda, lambda);
    DMLC_DECLARE_ALIAS(reg_alpha, alpha);
    DMLC_DECLARE_ALIAS(min_split_loss, gamma);
    DMLC_DECLARE_ALIAS(learning_rate, eta);
  }

  // calculate the cost of loss function
  inline double CalcGain(double sum_grad, double sum_hess) const 
  {//计算增益
    if (sum_hess < min_child_weight) return 0.0;
	
    if (max_delta_step == 0.0f) //默认是0
	{
      if (reg_alpha == 0.0f) 
	  {
        return Sqr(sum_grad) / (sum_hess + reg_lambda);//平方
      } else {
        return Sqr(ThresholdL1(sum_grad, reg_alpha)) / (sum_hess + reg_lambda);
      }
    } 
	else {
      double w = CalcWeight(sum_grad, sum_hess);
      double ret = sum_grad * w + 0.5 * (sum_hess + reg_lambda) * Sqr(w);
      if (reg_alpha == 0.0f) {
        return - 2.0 * ret;
      } else {
        return - 2.0 * (ret + reg_alpha * std::abs(w));
      }
    }
  }
  // calculate cost of loss function with four statistics
  inline double CalcGain(double sum_grad, double sum_hess,
                         double test_grad, double test_hess) const 
  {//计算增益
    double w = CalcWeight(sum_grad, sum_hess);
    double ret = test_grad * w  + 0.5 * (test_hess + reg_lambda) * Sqr(w);
    if (reg_alpha == 0.0f) {//默认是0
      return - 2.0 * ret;
    } else {
      return - 2.0 * (ret + reg_alpha * std::abs(w));
    }
  }
  // calculate weight given the statistics  
  inline double CalcWeight(double sum_grad, double sum_hess) const 
  {//训练参数完成计算得分
    if (sum_hess < min_child_weight) return 0.0; //最小得分是1 默认的
    
	double dw;
    if (reg_alpha == 0.0f) { //默认是0，
      dw = -sum_grad / (sum_hess + reg_lambda);//reg_lambda默认是1，正则
    } 
	else 
	{
      dw = -ThresholdL1(sum_grad, reg_alpha) / (sum_hess + reg_lambda);//在-reg_alpha~reg_alpha范围，则为0，否则为其差值
    }
    if (max_delta_step != 0.0f) {//默认是0
      if (dw > max_delta_step) dw = max_delta_step;
      if (dw < -max_delta_step) dw = -max_delta_step;
    }
    return dw;
  }
  
  
  /*! \brief whether need forward small to big search: default right */
  //若是选择了前向搜索，则缺失值会被处理成往右侧流动
  inline bool need_forward_search(float col_density, bool indicator) const 
  {
	  //col_density是一个稀疏性的体现0-1之间，小则密集      头尾相等
	  //default_direction：0表示不确定，1表示left 2表示right； 
      //opt_dense_col 默认是1
    return this->default_direction == 2 ||
        (default_direction == 0 && (col_density < opt_dense_col) && !indicator);
  }
  /*! \brief whether need backward big to small search: default left */
  //判断是否进行后向搜索，若缺失值处理默认方向左侧
  inline bool need_backward_search(float col_density, bool indicator) const 
  {//只跟方向有关
    return this->default_direction != 2;
  }
  /*! \brief given the loss change, whether we need to invoke pruning */
  inline bool need_prune(double loss_chg, int depth) const {
    return loss_chg < this->min_split_loss;
  }
  /*! \brief whether we can split with current hessian */
  inline bool cannot_split(double sum_hess, int depth) const {
    return sum_hess < this->min_child_weight * 2.0;
  }
  /*! \brief maximum sketch size */
  inline unsigned max_sketch_size() const {
    unsigned ret = static_cast<unsigned>(sketch_ratio / sketch_eps);
    CHECK_GT(ret, 0);
    return ret;
  }

 protected:
  // functions for L1 cost
  inline static double ThresholdL1(double w, double lambda) {
    if (w > +lambda) return w - lambda;
    if (w < -lambda) return w + lambda;
    return 0.0;
  }
  inline static double Sqr(double a) {
    return a * a;
  }
};

/*! \brief core statistics used for tree construction */
//用于存放节点状态信息，是核心的统计存储信息
struct GradStats {
  /*! \brief sum gradient statistics  g*/
  //  一阶梯度的和 
  double sum_grad;
  /*! \brief sum hessian statistics   h */
  //二阶梯度的和 
  double sum_hess;
  /*!
   * \brief whether this is simply statistics and we only need to call
   *   Add(gpair), instead of Add(gpair, info, ridx)
   用于区分是调用哪个add函数，是否采样，static量
   */
  static const int kSimpleStats = 1;
  /*! \brief constructor, the object must be cleared during construction */
  //显示构造函数，需要传递训练参数，其实质是清空0
  explicit GradStats(const TrainParam& param) 
  {//构造函数
    this->Clear();
  }
  /*! \brief clear the statistics */
  //初始为0
  inline void Clear() {
    sum_grad = sum_hess = 0.0f;//为0
  }
  /*! \brief check if necessary information is ready */
  //啥都没干，留个后面做核查元信息
  inline static void CheckInfo(const MetaInfo& info) 
  {
  }
  /*!
   * \brief accumulate statistics
   * \param p the gradient pair
   */
   //融合bst_gpair
  inline void Add(bst_gpair p) 
  {//增加g 和H
    this->Add(p.grad, p.hess);
  }
  /*!
   * \brief accumulate statistics, more complicated version
   * \param gpair the vector storing the gradient statistics
   * \param info the additional information
   * \param ridx instance index of this instance
   */
   //融合一行的bst_gpair
  inline void Add(const std::vector<bst_gpair>& gpair,
                  const MetaInfo& info,
                  bst_uint ridx) 
  {
    const bst_gpair& b = gpair[ridx];//读取的对来增加
    this->Add(b.grad, b.hess);
  }
  
  
  /*! \brief calculate leaf weight  */
  //计算叶子的权重分值，计算逻辑在参数那
  inline double CalcWeight(const TrainParam& param) const 
  {
    return param.CalcWeight(sum_grad, sum_hess);
  }
  
  
  /*! \brief calculate gain of the solution */
  //计算增益，通过训练参数计算
  inline double CalcGain(const TrainParam& param) const {//
    return param.CalcGain(sum_grad, sum_hess);
  }
  
  
  /*! \brief add statistics to the data */
  //融合 GradStats
  inline void Add(const GradStats& b) {
    this->Add(b.sum_grad, b.sum_hess);
  }
  
  
  /*! \brief same as add, reduce is used in All Reduce */
  // 融合的方式，静态方法，GradStats
  inline static void Reduce(GradStats& a, const GradStats& b) { // NOLINT(*)
    a.Add(b);
  }
 

 /*! \brief set current value to a - b */
 //  两个节点的g和h的差值，存入状态
  inline void SetSubstract(const GradStats& a, const GradStats& b) {
    sum_grad = a.sum_grad - b.sum_grad;
    sum_hess = a.sum_hess - b.sum_hess;
  }
  
  
  /*! \return whether the statistics is not used yet */
  //是否被使用了
  inline bool Empty() const {
    return sum_hess == 0.0;
  }
  
  
  /*! \brief set leaf vector value based on statistics */
  //基于统计留个接口供对叶子节点处理
  inline void SetLeafVec(const TrainParam& param, bst_float *vec) const {
  }
  // constructor to allow inheritance 构造函数
  GradStats() {}
  
  
  /*! \brief add statistics to the data */
  //grad，hess融入
  inline void Add(double grad, double hess) {//增加融合
    sum_grad += grad; sum_hess += hess;
  }
};

/*!
 * \brief statistics that is helpful to store
 *   and represent a split solution for the tree
 */
 //节点分类的信息
struct SplitEntry {
  /*! \brief loss change after split this node */
	//分裂节点前后“信息增益”的改变量
  bst_float loss_chg;
  /*! \brief split index                      */
  //分裂的特征编号
  unsigned sindex;
  /*! \brief split value                   */
  //特征分裂的值
  float split_value;
  /*! \brief constructor */
  //构造函数，初始为0
  SplitEntry() : loss_chg(0.0f), sindex(0), split_value(0.0f) {}
  /*!
   * \brief decides whether we can replace current entry with the given statistics
   *   This function gives better priority to lower index when loss_chg == new_loss_chg.
   *   Not the best way, but helps to give consistent result during multi-thread execution.
   * \param new_loss_chg the loss reduction get through the split
   * \param split_index the feature index where the split is on
   */
   //判断是否需要替换本节点的分裂点，对同等损失的优先选择了特征编号小的，为了保持一致性
  inline bool NeedReplace(bst_float new_loss_chg, unsigned split_index) const 
  {
	//若new_loss_chg大，更新；
	//若new_loss_chg小，不更新；
	//若是new_loss_chg=loss_chg，本特征号小时，则不更新，若是特征大，则更新
    if (this->split_index() <= split_index) {
      return new_loss_chg > this->loss_chg;
    } else {
      return !(this->loss_chg > new_loss_chg);
    }
  }
  /*!
   * \brief update the split entry, replace it if e is better
   * \param e candidate split solution
   * \return whether the proposed split is better and can replace current split
   */
   //根据参数更新分裂节点信息
  inline bool Update(const SplitEntry& e) {
    if (this->NeedReplace(e.loss_chg, e.split_index())) {//需要更新
      this->loss_chg = e.loss_chg;
      this->sindex = e.sindex;//包括了对缺省样本的处理
      this->split_value = e.split_value;
      return true;
    } else {
      return false;
    }
  }
  /*!
   * \brief update the split entry, replace it if e is better
   * \param new_loss_chg loss reduction of new candidate
   * \param split_index feature index to split on
   * \param new_split_value the split point
   * \param default_left whether the missing value goes to left
   * \return whether the proposed split is better and can replace current split
   */
  inline bool Update(bst_float new_loss_chg, unsigned split_index,
                     float new_split_value, bool default_left) 
  {//跟新最佳分裂点
    if (this->NeedReplace(new_loss_chg, split_index)) 
	{
      this->loss_chg = new_loss_chg;//表示需要被替换
	  //若默认是左侧，则分裂特征对missing设置为左侧，根据参数来的
      if (default_left) split_index |= (1U << 31);
      this->sindex = split_index;
      this->split_value = new_split_value;
      return true;
    } else {
      return false;
    }
  }
  /*! \brief same as update, used by AllReduce*/
  //与update一样，只是用来分布式中的汇总
  inline static void Reduce(SplitEntry& dst, const SplitEntry& src) { // NOLINT(*)
    dst.Update(src);
  }
  /*!\return feature index to split on */
  //返回分裂索引值
  inline unsigned split_index() const {
    return sindex & ((1U << 31) - 1U);//((1U << 31) - 1U) 011111..11 获取低31位值，最高位保留
  }
  /*!\return whether missing value goes to left branch */
  //判断分裂特征对于缺省数据样本点的处理，判断是否missing值走左侧
  inline bool default_left() const {
    return (sindex >> 31) != 0;//最高位是1则走左侧，否则是右侧
  }
};

}  // namespace tree
}  // namespace xgboost
#endif  // XGBOOST_TREE_PARAM_H_
