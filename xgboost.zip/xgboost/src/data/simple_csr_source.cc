/*!
 * Copyright 2015 by Contributors
 * \file simple_csr_source.cc
 */
#include <dmlc/base.h>
#include <xgboost/logging.h>
#include "./simple_csr_source.h"

namespace xgboost {
namespace data {

void SimpleCSRSource::Clear() {
  row_data_.clear();
  row_ptr_.resize(1);
  row_ptr_[0] = 0;
  this->info.Clear();
}

void SimpleCSRSource::CopyFrom(DMatrix* src) {
  this->Clear();
  this->info = src->info();
  dmlc::DataIter<RowBatch>* iter = src->RowIterator();
  iter->BeforeFirst();
  while (iter->Next()) {
    const RowBatch &batch = iter->Value();
    for (size_t i = 0; i < batch.size; ++i) {
      RowBatch::Inst inst = batch[i];
      row_data_.insert(row_data_.end(), inst.data, inst.data + inst.length);
      row_ptr_.push_back(row_ptr_.back() + inst.length);
    }
  }
}

void SimpleCSRSource::CopyFrom(dmlc::Parser<uint32_t>* parser) 
{//从文件中拷贝
  this->Clear();
  while (parser->Next()) 
  {//获取下一个---不断获取数据的过程

	const dmlc::RowBlock<uint32_t>& batch = parser->Value();//简单返回数据
	
    if (batch.label != nullptr) {//是否有标签---有则插入
      info.labels.insert(info.labels.end(), batch.label, batch.label + batch.size);
    }
    if (batch.weight != nullptr) {//是否有得分值
      info.weights.insert(info.weights.end(), batch.weight, batch.weight + batch.size);
    }
	
    CHECK(batch.index != nullptr);//成立，表示必须有特征
	
	
    // update information
    this->info.num_row += batch.size;//统计行数
	
    // copy the data over
    for (size_t i = batch.offset[0]; i < batch.offset[batch.size]; ++i) 
	{//batch数据导入

      uint32_t index = batch.index[i];
	  //在此之前都不会出现，对是nullptr的处理，而在GetBlock中有检测是否空的情况
      bst_float fvalue = batch.value == nullptr ? 1.0f : batch.value[i];//若是缺少则为 1
	  
      row_data_.push_back(SparseBatch::Entry(index, fvalue));//加入DataSource中
	  
	  //表明标示是从0开始的
      this->info.num_col = std::max(this->info.num_col,
                                    static_cast<uint64_t>(index + 1));//最大特征数+1

    }
	
	
    size_t top = row_ptr_.size();//偏移量修正
    for (size_t i = 0; i < batch.size; ++i) 
	{
      row_ptr_.push_back(row_ptr_[top - 1] + batch.offset[i + 1] - batch.offset[0]);
    }
  }
  
  this->info.num_nonzero = static_cast<uint64_t>(row_data_.size());//有多少个对表示数据的总的非零特征值
}

void SimpleCSRSource::LoadBinary(dmlc::Stream* fi) {
  int tmagic;
  
  CHECK(fi->Read(&tmagic, sizeof(tmagic)) == sizeof(tmagic)) << "invalid input file format";
  CHECK_EQ(tmagic, kMagic) << "invalid format, magic number mismatch";
  
  info.LoadBinary(fi);//DataSource数据加载中的 MetaInfo info;
  fi->Read(&row_ptr_);
  fi->Read(&row_data_);
}

void SimpleCSRSource::SaveBinary(dmlc::Stream* fo) const {
  int tmagic = kMagic;
  fo->Write(&tmagic, sizeof(tmagic));
  info.SaveBinary(fo);
  fo->Write(row_ptr_);
  fo->Write(row_data_);
}

void SimpleCSRSource::BeforeFirst() {
  at_first_ = true;
}

bool SimpleCSRSource::Next() {
  if (!at_first_) return false;
  at_first_ = false;
  batch_.size = row_ptr_.size() - 1;
  batch_.base_rowid = 0;
  batch_.ind_ptr = dmlc::BeginPtr(row_ptr_);
  batch_.data_ptr = dmlc::BeginPtr(row_data_);
  return true;
}

const RowBatch& SimpleCSRSource::Value() const {
  return batch_;
}

}  // namespace data
}  // namespace xgboost
