/*!
 * Copyright 2014 by Contributors
 * \file simple_dmatrix.cc
 * \brief the input data structure for gradient boosting
 * \author Tianqi Chen
 */
#include <xgboost/data.h>
#include <limits>
#include <algorithm>
#include <vector>
#include "./simple_dmatrix.h"
#include "../common/random.h"
#include "../common/group_data.h"

namespace xgboost {
namespace data {

bool SimpleDMatrix::ColBatchIter::Next() 
{
  //若是数据指针超出了page可存储的最大范围，则表示数据到头了
  if (data_ptr_ >= cpages_.size()) return false;
  
  data_ptr_ += 1;//ColBatch的编号
  
  //返回当前的page内容
  SparsePage* pcol = cpages_[data_ptr_ - 1].get();
  
  //基于本块信息进行修改
  batch_.size = col_index_.size();//数据大小
  
  col_data_.resize(col_index_.size(), SparseBatch::Inst(NULL, 0));//设置块大小
  
  for (size_t i = 0; i < col_data_.size(); ++i) 
  {//填充块
    const bst_uint ridx = col_index_[i];//列的编号
	//读取page的内容，这里的page的存储方式按列的，内部已有的函数基本都不能用，因为设计之初是为了行而设计的
    col_data_[i] = SparseBatch::Inst(dmlc::BeginPtr(pcol->data) + pcol->offset[ridx],static_cast<bst_uint>(pcol->offset[ridx + 1] - pcol->offset[ridx]));
  }
  //batch_存入
  batch_.col_index = dmlc::BeginPtr(col_index_);
  batch_.col_data = dmlc::BeginPtr(col_data_);
  return true;
}

dmlc::DataIter<ColBatch>* SimpleDMatrix::ColIterator() {
  size_t ncol = this->info().num_col;
  col_iter_.col_index_.resize(ncol);
  for (size_t i = 0; i < ncol; ++i) {
    col_iter_.col_index_[i] = static_cast<bst_uint>(i);
  }
  col_iter_.BeforeFirst();
  return &col_iter_;
}
//函数功能：基于特征索引值将其整合为一个Batch返回数据
//筛选一些特征编号，将其整合
dmlc::DataIter<ColBatch>* SimpleDMatrix::ColIterator(const std::vector<bst_uint>&fset) 
{
	
  size_t ncol = this->info().num_col;//获取总特征数
  col_iter_.col_index_.resize(0);//将本列存储的特征索引清空
  for (size_t i = 0; i < fset.size(); ++i) 
  {//重新获取了本数据中的有效特征编号
    if (fset[i] < ncol) col_iter_.col_index_.push_back(fset[i]);
  }
  col_iter_.BeforeFirst();//设置为第一个page，设置为0
  return &col_iter_; //
}

void SimpleDMatrix::InitColAccess(const std::vector<bool> &enabled,//默认都是true
                                  float pkeep,//1.0
                                  size_t max_row_perbatch) 
{//获取列信息 cpages_，col_size_
  if (this->HaveColAccess()) return;//没有数据

  col_iter_.cpages_.clear();//清除所有的块
  
  if (info().num_row < max_row_perbatch) 
  {
    std::unique_ptr<SparsePage> page(new SparsePage());//存放的是数据
	//page的min_index=0
    this->MakeOneBatch(enabled, pkeep, page.get());//获取一个batch存入到page中（列形式存）
	
    col_iter_.cpages_.push_back(std::move(page));//将page存入总cpages_中
  } 
  else 
  {
    this->MakeManyBatch(enabled, pkeep, max_row_perbatch);
  }
  // setup col-size
  col_size_.resize(info().num_col);//设置列
  
  std::fill(col_size_.begin(), col_size_.end(), 0);
  
  for (size_t i = 0; i < col_iter_.cpages_.size(); ++i) 
  {//块
    SparsePage *pcol = col_iter_.cpages_[i].get();
    for (size_t j = 0; j < pcol->Size(); ++j)//没行 
	{//统计同一列的entry的个数
      col_size_[j] += pcol->offset[j + 1] - pcol->offset[j];//
    }
  }
}

// internal function to make one batch from row iter.
void SimpleDMatrix::MakeOneBatch(const std::vector<bool>& enabled,//true
                                 float pkeep,//1
                                 SparsePage *pcol) 
{//存放了按照列存的数据  buffered_rowset_，
  // clear rowset
  buffered_rowset_.clear();//在此处开始
  // bit map
  int nthread;
  std::vector<bool> bmap;
  #pragma omp parallel
  {
    nthread = omp_get_num_threads();//进程数
  }

  pcol->Clear();
  common::ParallelGroupBuilder<SparseBatch::Entry> builder(&pcol->offset, &pcol->data);
  builder.InitBudget(info().num_col, nthread);
  // start working
  dmlc::DataIter<RowBatch>* iter = this->RowIterator();//行的batch
  iter->BeforeFirst();//获取第一行
  while (iter->Next()) 
  {
    const RowBatch& batch = iter->Value();//第一个batch
    bmap.resize(bmap.size() + batch.size, true);//
    std::bernoulli_distribution coin_flip(pkeep);//贝努力分布  发生概率值为1
	
    auto& rnd = common::GlobalRandom();//随机数

    long batch_size = static_cast<long>(batch.size); // NOLINT(*)
    for (long i = 0; i < batch_size; ++i) { // NOLINT(*)
      bst_uint ridx = static_cast<bst_uint>(batch.base_rowid + i);//行号的索引
      if (pkeep == 1.0f || coin_flip(rnd)) 
	  {
        buffered_rowset_.push_back(ridx);//初始化buffered_rowset_
      } else {
        bmap[i] = false;
      }
    }
    #pragma omp parallel for schedule(static)
    for (long i = 0; i < batch_size; ++i) 
	{ // NOLINT(*)
      int tid = omp_get_thread_num();
      bst_uint ridx = static_cast<bst_uint>(batch.base_rowid + i);
      if (bmap[ridx]) 
	  {
        RowBatch::Inst inst = batch[i];
        for (bst_uint j = 0; j < inst.length; ++j) 
		{
          if (enabled[inst[j].index])//列存在的
		  {
            builder.AddBudget(inst[j].index, tid);//统计列对应的个数
          }
        }
      }
    }//统计出了列的实际长度
  }
  builder.InitStorage();//求和过程

  iter->BeforeFirst();
  while (iter->Next()) 
  {
    const RowBatch& batch = iter->Value();
    #pragma omp parallel for schedule(static)
    for (long i = 0; i < static_cast<long>(batch.size); ++i) 
	{ // NOLINT(*)
      int tid = omp_get_thread_num();
      bst_uint ridx = static_cast<bst_uint>(batch.base_rowid + i);//行
      if (bmap[ridx]) {
        RowBatch::Inst inst = batch[i];
        for (bst_uint j = 0; j < inst.length; ++j) 
		{
          if (enabled[inst[j].index]) {
            builder.Push(inst[j].index,//第几个列
                         SparseBatch::Entry((bst_uint)(batch.base_rowid+i),//行号
                                            inst[j].fvalue), tid);//特征
          }
        }
      }
    }
  }

  CHECK_EQ(pcol->Size(), info().num_col);
  // sort columns
  bst_omp_uint ncol = static_cast<bst_omp_uint>(pcol->Size());
  #pragma omp parallel for schedule(dynamic, 1) num_threads(nthread)
  for (bst_omp_uint i = 0; i < ncol; ++i) {
    if (pcol->offset[i] < pcol->offset[i + 1]) 
	{
      std::sort(dmlc::BeginPtr(pcol->data) + pcol->offset[i],
                dmlc::BeginPtr(pcol->data) + pcol->offset[i + 1],
                SparseBatch::Entry::CmpValue);//按照特征值的排序
    }
  }
}

void SimpleDMatrix::MakeManyBatch(const std::vector<bool>& enabled,
                                  float pkeep,
                                  size_t max_row_perbatch) {
  size_t btop = 0;
  std::bernoulli_distribution coin_flip(pkeep);
  auto& rnd = common::GlobalRandom();
  buffered_rowset_.clear();
  // internal temp cache
  SparsePage tmp; tmp.Clear();
  // start working
  dmlc::DataIter<RowBatch>* iter = this->RowIterator();
  iter->BeforeFirst();

  while (iter->Next()) {
    const RowBatch &batch = iter->Value();
    for (size_t i = 0; i < batch.size; ++i) {
      bst_uint ridx = static_cast<bst_uint>(batch.base_rowid + i);
      if (pkeep == 1.0f || coin_flip(rnd)) {
        buffered_rowset_.push_back(ridx);
        tmp.Push(batch[i]);
      }
      if (tmp.Size() >= max_row_perbatch) {
        std::unique_ptr<SparsePage> page(new SparsePage());
        this->MakeColPage(tmp.GetRowBatch(0), btop, enabled, page.get());
        col_iter_.cpages_.push_back(std::move(page));
        btop = buffered_rowset_.size();
        tmp.Clear();
      }
    }
  }

  if (tmp.Size() != 0) {
    std::unique_ptr<SparsePage> page(new SparsePage());
    this->MakeColPage(tmp.GetRowBatch(0), btop, enabled, page.get());
    col_iter_.cpages_.push_back(std::move(page));
  }
}

// make column page from subset of rowbatchs
void SimpleDMatrix::MakeColPage(const RowBatch& batch,
                                size_t buffer_begin,
                                const std::vector<bool>& enabled,
                                SparsePage* pcol) {
  int nthread;
  #pragma omp parallel
  {
    nthread = omp_get_num_threads();
    int max_nthread = std::max(omp_get_num_procs() / 2 - 2, 1);
    if (nthread > max_nthread) {
      nthread = max_nthread;
    }
  }
  pcol->Clear();
  common::ParallelGroupBuilder<SparseBatch::Entry>
      builder(&pcol->offset, &pcol->data);
  builder.InitBudget(info().num_col, nthread);
  bst_omp_uint ndata = static_cast<bst_uint>(batch.size);
  #pragma omp parallel for schedule(static) num_threads(nthread)
  for (bst_omp_uint i = 0; i < ndata; ++i) {
    int tid = omp_get_thread_num();
    RowBatch::Inst inst = batch[i];
    for (bst_uint j = 0; j < inst.length; ++j) {
      const SparseBatch::Entry &e = inst[j];
      if (enabled[e.index]) {
        builder.AddBudget(e.index, tid);
      }
    }
  }
  builder.InitStorage();
  #pragma omp parallel for schedule(static) num_threads(nthread)
  for (bst_omp_uint i = 0; i < ndata; ++i) {
    int tid = omp_get_thread_num();
    RowBatch::Inst inst = batch[i];
    for (bst_uint j = 0; j < inst.length; ++j) {
      const SparseBatch::Entry &e = inst[j];
      builder.Push(
          e.index,
          SparseBatch::Entry(buffered_rowset_[i + buffer_begin], e.fvalue),
          tid);
    }
  }
  CHECK_EQ(pcol->Size(), info().num_col);
  // sort columns
  bst_omp_uint ncol = static_cast<bst_omp_uint>(pcol->Size());
  #pragma omp parallel for schedule(dynamic, 1) num_threads(nthread)
  for (bst_omp_uint i = 0; i < ncol; ++i) {
    if (pcol->offset[i] < pcol->offset[i + 1]) {
      std::sort(dmlc::BeginPtr(pcol->data) + pcol->offset[i],
                dmlc::BeginPtr(pcol->data) + pcol->offset[i + 1],
                SparseBatch::Entry::CmpValue);
    }
  }
}

bool SimpleDMatrix::SingleColBlock() const {
  return col_iter_.cpages_.size() <= 1;
}
}  // namespace data
}  // namespace xgboost
