/*!
 * Copyright 2015 by Contributors
 * \file simple_dmatrix.h
 * \brief In-memory version of DMatrix.
 * \author Tianqi Chen
 */
#ifndef XGBOOST_DATA_SIMPLE_DMATRIX_H_
#define XGBOOST_DATA_SIMPLE_DMATRIX_H_

#include <xgboost/base.h>
#include <xgboost/data.h>
#include <vector>
#include <algorithm>
#include <cstring>
#include "./sparse_batch_page.h"

namespace xgboost {
namespace data {

class SimpleDMatrix : public DMatrix {
 public:
  explicit SimpleDMatrix(std::unique_ptr<DataSource>&& source)
      : source_(std::move(source)) {}// 移动到source_中

  MetaInfo& info() override {//返回source的info信息
    return source_->info;//返回元信息
  }

  const MetaInfo& info() const override {
    return source_->info;
  }

  dmlc::DataIter<RowBatch>* RowIterator() override {//返回行
    dmlc::DataIter<RowBatch>* iter = source_.get();
    iter->BeforeFirst();
    return iter;
  }

  bool HaveColAccess() const override {//是否有列
    return col_size_.size() != 0;
  }

  const RowSet& buffered_rowset() const override {//返回buffered_rowset_
    return buffered_rowset_;
  }

  size_t GetColSize(size_t cidx) const {//返回列的长度，，，，
    return col_size_[cidx];
  }

  float GetColDensity(size_t cidx) const override 
  {
    size_t nmiss = buffered_rowset_.size() - col_size_[cidx];
    return 1.0f - (static_cast<float>(nmiss)) / buffered_rowset_.size();
  }

  dmlc::DataIter<ColBatch>* ColIterator() override;//返回列

  dmlc::DataIter<ColBatch>* ColIterator(const std::vector<bst_uint>& fset) override;//返回列

  
  
  void InitColAccess(const std::vector<bool>& enabled,
                     float subsample,
                     size_t max_row_perbatch) override;

  bool SingleColBlock() const override;

 private:
  // in-memory column batch iterator.
  //列数据结构的迭代器
  struct ColBatchIter: dmlc::DataIter<ColBatch> 
  {//内置结构体 ColBatchIter
   public:
   //默认构造，对
    ColBatchIter() : data_ptr_(0) {}
	
    void BeforeFirst() override {
      data_ptr_ = 0;
    }
    const ColBatch &Value() const override {
      return batch_;//返回块
    }
    bool Next() override;

   private:
    // allow SimpleDMatrix to access it.  
	//允许SimpleDMatrix对象访问此类数据
	//设计就是内部的一个封装，对所属雇主SimpleDMatrix开放
    friend class SimpleDMatrix;
    
	// data content
	//列的编号也就是特征号，不是列的偏移量，不需要因为数据是Inst形式存放了
    std::vector<bst_uint> col_index_;
	
    // column content    
	//数据实际存储位置，按照列存放
    std::vector<ColBatch::Inst> col_data_;
	
    // column sparse pages  
	//指针可变数组，所指对象数据结构是 SparsePage
	//SparsePage对象按照类似“行”思想存放“列”，后期基本不能使用本类的成员函数
	//因为此类基本都是行的数据结构被使用
    std::vector<std::unique_ptr<SparsePage> > cpages_;
	
    // data pointer  
	//指示器表示此ColBatch是第几个了
    size_t data_ptr_;  
    // temporal space for batch
	//一个包层接口方便外部使用，可利用已经构造好的函数进行访问
    ColBatch batch_;
  };

  // source data pointer.   数据源的存储
  std::unique_ptr<DataSource> source_;
  // column iterator  列的指示器
  ColBatchIter col_iter_;//迭代器，用于访问列的块效果---本身是继承了接口DataIter，可以用其去访问
  // list of row index that are buffered.  行表
  RowSet buffered_rowset_;
  /*! \brief sizeof column data */  //列的长度，，，因为稀疏嘛
  std::vector<size_t> col_size_;

  // internal function to make one batch from row iter.
  void MakeOneBatch(const std::vector<bool>& enabled,
                    float pkeep,
                    SparsePage *pcol);

  void MakeManyBatch(const std::vector<bool>& enabled,
                     float pkeep,
                     size_t max_row_perbatch);

  void MakeColPage(const RowBatch& batch,
                   size_t buffer_begin,
                   const std::vector<bool>& enabled,
                   SparsePage* pcol);
};
}  // namespace data
}  // namespace xgboost
#endif  // XGBOOST_DATA_SIMPLE_DMATRIX_H_
