/*!
 * Copyright 2014 by Contributors
 * \file learner.cc
 * \brief Implementation of learning algorithm.
 * \author Tianqi Chen
 */
#include <xgboost/learner.h>
#include <algorithm>
#include <vector>
#include <utility>
#include <string>
#include <sstream>
#include <limits>
#include <iomanip>
#include "./common/io.h"
#include "./common/random.h"

namespace xgboost {
// implementation of base learner.   检测
bool Learner::AllowLazyCheckPoint() const 
{
  return gbm_->AllowLazyCheckPoint();
}

std::vector<std::string>
Learner::Dump2Text(const FeatureMap& fmap, int option) const {//实际调用的gbm完成
  return gbm_->Dump2Text(fmap, option);
}

// simple routine to convert any data to string
template<typename T>
inline std::string ToString(const T& data) {
  std::ostringstream os;
  os << data;
  return os.str();
}

/*! \brief training parameter for regression  模型参数结构*/
struct LearnerModelParam: public dmlc::Parameter<LearnerModelParam> {
  /* \brief global bias  模型基础分*/
  float base_score;
  /* \brief number of features  总特征数*/
  unsigned num_feature;
  /* \brief number of classes, if it is multi-class classification  类的个数*/
  int num_class;
  /*! \brief reserved field  预留的空间*/
  int reserved[31];
  /*! \brief constructor */
  LearnerModelParam() {
    std::memset(this, 0, sizeof(LearnerModelParam));
    base_score = 0.5f;//基础分是0.5，默认
  }
  //xu
  void Debug()
  {
	std::cout<<"=====LearnerModelParam Dubeg================" <<std::cout;  
	std::cout<<"base_score:" <<base_score<<std::cout;
	std::cout<<"num_feature:" <<num_feature<<std::cout;
	std::cout<<"num_class:" <<num_class<<std::cout;
	std::cout<<"reserved:" <<std::cout;
	for(int i=0;i!=31;i++)
		std::cout<<reserved[i]<<"#";
	std::cout<<std::cout;
  }
  
  // declare parameters
  DMLC_DECLARE_PARAMETER(LearnerModelParam) {
    DMLC_DECLARE_FIELD(base_score).set_default(0.5f)
        .describe("Global bias of the model.");
    DMLC_DECLARE_FIELD(num_feature).set_default(0)
        .describe("Number of features in training data,"\
                  " this parameter will be automatically detected by learner.");
    DMLC_DECLARE_FIELD(num_class).set_default(0).set_lower_bound(0)
        .describe("Number of class option for multi-class classifier. "\
                  " By default equals 0 and corresponds to binary classifier.");
  }
};
//训练参数结构
struct LearnerTrainParam: public dmlc::Parameter<LearnerTrainParam> {
  // stored random seed  随机种子
  int seed;
  // whether seed the PRNG each iteration 每次迭代的种子
  bool seed_per_iteration;
  // data split mode, can be row, col, or none.  分裂模型---行，列或者none
  int dsplit;
  // internal test flag   内测试的标志
  std::string test_flag;
  // maximum buffered row value   最大的行值
  float prob_buffer_row;
  // maximum row per batch.    每个batch的最大值
  size_t max_row_perbatch;
  //xu
  void Debug()
  {
	std::cout<<"=====LearnerTrainParam Dubeg================" <<std::cout;  
	std::cout<<"seed:" <<seed<<std::cout;
	std::cout<<"seed_per_iteration:" <<seed_per_iteration<<std::cout;
	std::cout<<"dsplit:" <<dsplit<<std::cout;
	std::cout<<"test_flag:" <<test_flag<<std::cout;
	std::cout<<"prob_buffer_row:" <<prob_buffer_row<<std::cout;
	std::cout<<"max_row_perbatch:" <<max_row_perbatch<<std::cout;
  }  
  
  // declare parameters  声明参数
  DMLC_DECLARE_PARAMETER(LearnerTrainParam) 
  {
    DMLC_DECLARE_FIELD(seed).set_default(0)
        .describe("Random number seed during training.");
    DMLC_DECLARE_FIELD(seed_per_iteration).set_default(false)
        .describe("Seed PRNG determnisticly via iterator number, "\
                  "this option will be switched on automatically on distributed mode.");
    DMLC_DECLARE_FIELD(dsplit).set_default(0)
        .add_enum("auto", 0)
        .add_enum("col", 1)
        .add_enum("row", 2)
        .describe("Data split mode for distributed trainig. ");
    DMLC_DECLARE_FIELD(test_flag).set_default("")
        .describe("Internal test flag");
    DMLC_DECLARE_FIELD(prob_buffer_row).set_default(1.0f).set_range(0.0f, 1.0f)
        .describe("Maximum buffered row portion");
    DMLC_DECLARE_FIELD(max_row_perbatch).set_default(std::numeric_limits<size_t>::max())
        .describe("maximum row per batch.");
  }
};

DMLC_REGISTER_PARAMETER(LearnerModelParam);
DMLC_REGISTER_PARAMETER(LearnerTrainParam);

/*!
 * \brief learner that performs gradient boosting for a specific objective function.
 *  It does training and prediction.
 */
class LearnerImpl : public Learner {
 public:
  explicit LearnerImpl(const std::vector<DMatrix*>& cache_mats)
      noexcept(false)//允许抛出异常 
  {
    // setup the cache setting in constructor.
    CHECK_EQ(cache_.size(), 0);//等于0，则通过，否则退出程序
    
	size_t buffer_size = 0;
    for (auto it  = cache_mats.begin(); it != cache_mats.end(); ++it) 
	{//这里面有train,test data
      // avoid duplication.   begin--it 就会返回最后一个 it
      if (std::find(cache_mats.begin(), it, *it) != it) continue;
      
	  DMatrix* pmat = *it;//获取
      pmat->cache_learner_ptr_ = this;//数据学习对象
	  
      cache_.push_back(CacheEntry(pmat, buffer_size, pmat->info().num_row));//开始的偏移为0
	  
      buffer_size += pmat->info().num_row;//第二数据集合的偏移量
    }
    pred_buffer_size_ = buffer_size;//表示所有数据集合行数的总量
    // boosted tree
    name_obj_ = "reg:linear";//默认设置就是回归：线性
    name_gbm_ = "gbtree";//gbtree
  }

  void Configure(const std::vector<std::pair<std::string, std::string> >& args) override 
  {//配置信息
    
	tparam.InitAllowUnknown(args);//初始化 tparam 参数  
	//xu
	tparam.Debug();
	
    // add to configurations
    cfg_.clear();//清除，等待配置
    for (const auto& kv : args) 
	{
      if (kv.first == "eval_metric") 
	  {//评估指标
        // check duplication
		/*
		　　C++11提供了对匿名函数的支持,称为Lambda函数(也叫Lambda表达式). Lambda表达式具体形式如下:
			[capture--可以使用的外部变量--传地址则能够修改外部变量](parameters){body}
		*/		
        auto dup_check = [&kv](const std::unique_ptr<Metric>&m)//确认 m参数就是metrics_的元素
		{
          return m->Name() != kv.second;// auc  error
        };
		//std::all_of函数是判断从头到尾是否真，若是，则真
        if (std::all_of(metrics_.begin(), metrics_.end(), dup_check))
		{
          metrics_.emplace_back(Metric::Create(kv.second));//获取值，表示评估指标
        }
      } 
	  else 
	  {//非指标配置的
        cfg_[kv.first] = kv.second;
      }
    }
    // add additional parameter
    // These are cosntraints that need to be satisfied.
    if (tparam.dsplit == 0 && rabit::IsDistributed()) {//不会
      tparam.dsplit = 2;
    }

    if (cfg_.count("num_class") != 0) {//分类个数，此时默认是0
      cfg_["num_output_group"] = cfg_["num_class"];
      if (atoi(cfg_["num_class"].c_str()) > 1 && cfg_.count("objective") == 0) {
        cfg_["objective"] = "multi:softmax";
      }
    }

    if (cfg_.count("max_delta_step") == 0 &&
        cfg_.count("objective") != 0 &&
        cfg_["objective"] == "count:poisson") {//不成立
      cfg_["max_delta_step"] = "0.7";
    }

    if (cfg_.count("updater") == 0) {//cfg_.count("updater")=0
      if (tparam.dsplit == 1) {//dsplit=0，默认
        cfg_["updater"] = "distcol";
      } 
	  else if (tparam.dsplit == 2) {
        cfg_["updater"] = "grow_histmaker,prune";
      }
      
	  if (tparam.prob_buffer_row != 1.0f) {//prob_buffer_row==1.0
        cfg_["updater"] = "grow_histmaker,refresh,prune";
      }
    }
    if (cfg_.count("objective") == 0) {//不等0
      cfg_["objective"] = "reg:linear";
    }
    if (cfg_.count("booster") == 0) {//不等0
      cfg_["booster"] = "gbtree";
    }

    if (!this->ModelInitialized()) {//假，进入
      mparam.InitAllowUnknown(args);
      name_obj_ = cfg_["objective"];//binary:logistic
      name_gbm_ = cfg_["booster"];//name_gbm_=gbtree
    }

    common::GlobalRandom().seed(tparam.seed);//产生随机数--全局的

    // set number of features correctly.
    cfg_["num_feature"] = ToString(mparam.num_feature);//0
    if (gbm_.get() != nullptr) {//不进
      gbm_->Configure(cfg_.begin(), cfg_.end());//获取gbm值
    }
    if (obj_.get() != nullptr) {//不进
      obj_->Configure(cfg_.begin(), cfg_.end());
    }	
  }

  void InitModel() override {//加载模型入口
    this->LazyInitModel();
  }

  void Load(dmlc::Stream* fi) override {
    // TODO(tqchen) mark deprecation of old format.
    common::PeekableInStream fp(fi);
    // backward compatible header check.
    std::string header;
    header.resize(4);
    if (fp.PeekRead(&header[0], 4) == 4) {
      CHECK_NE(header, "bs64")
          << "Base64 format is no longer supported in brick.";
      if (header == "binf") {
        CHECK_EQ(fp.Read(&header[0], 4), 4);
      }
    }
    // use the peekable reader.
    fi = &fp;
    // read parameter
    CHECK_EQ(fi->Read(&mparam, sizeof(mparam)), sizeof(mparam))
        << "BoostLearner: wrong model format";
    {
      // backward compatibility code for compatible with old model type
      // for new model, Read(&name_obj_) is suffice
      uint64_t len;
      CHECK_EQ(fi->Read(&len, sizeof(len)), sizeof(len));
      if (len >= std::numeric_limits<unsigned>::max()) {
        int gap;
        CHECK_EQ(fi->Read(&gap, sizeof(gap)), sizeof(gap))
            << "BoostLearner: wrong model format";
        len = len >> static_cast<uint64_t>(32UL);
      }
      if (len != 0) {
        name_obj_.resize(len);
        CHECK_EQ(fi->Read(&name_obj_[0], len), len)
            <<"BoostLearner: wrong model format";
      }
    }
    CHECK(fi->Read(&name_gbm_))
        << "BoostLearner: wrong model format";
    // duplicated code with LazyInitModel
    obj_.reset(ObjFunction::Create(name_obj_));
    gbm_.reset(GradientBooster::Create(name_gbm_));
    gbm_->Load(fi);

    if (metrics_.size() == 0) {
      metrics_.emplace_back(Metric::Create(obj_->DefaultEvalMetric()));
    }
    this->base_score_ = mparam.base_score;
    gbm_->ResetPredBuffer(pred_buffer_size_);
    cfg_["num_class"] = ToString(mparam.num_class);
    obj_->Configure(cfg_.begin(), cfg_.end());
  }

  // rabit save model to rabit checkpoint
  void Save(dmlc::Stream *fo) const override {
    fo->Write(&mparam, sizeof(LearnerModelParam));
    fo->Write(name_obj_);
    fo->Write(name_gbm_);
    gbm_->Save(fo);
  }

  void UpdateOneIter(int iter, DMatrix* train) override 
  {//迭代训练
    
	CHECK(ModelInitialized())//验证 gbm_ 是否有对象
        << "Always call InitModel or LoadModel before update";
		
    if (tparam.seed_per_iteration || rabit::IsDistributed()) {//
      common::GlobalRandom().seed(tparam.seed * kRandSeedMagic + iter);
    }
    
	this->LazyInitDMatrix(train);//初始化数据---列相关的初始化
 
	this->PredictRaw(train, &preds_);//预测记录的值
	
    obj_->GetGradient(preds_, train->info(), iter, &gpair_);//获取梯度
	
    gbm_->DoBoost(train, this->FindBufferOffset(train), &gpair_);//构建树
  }

  void BoostOneIter(int iter,
                    DMatrix* train,
                    std::vector<bst_gpair>* in_gpair) override {
    if (tparam.seed_per_iteration || rabit::IsDistributed()) {
      common::GlobalRandom().seed(tparam.seed * kRandSeedMagic + iter);
    }
    this->LazyInitDMatrix(train);
    gbm_->DoBoost(train, this->FindBufferOffset(train), in_gpair);
  }

  std::string EvalOneIter(int iter,
                          const std::vector<DMatrix*>& data_sets,
                          const std::vector<std::string>& data_names) override 
  {//评估指标
    std::ostringstream os;
    os << '[' << iter << ']'<< std::setiosflags(std::ios::fixed);
    for (size_t i = 0; i < data_sets.size(); ++i) 
	{
      this->PredictRaw(data_sets[i], &preds_);
      obj_->EvalTransform(&preds_);//对输出预测值preds_做变换
      for (auto& ev : metrics_) //输出多个评估指标
	  {
        os << '\t' << data_names[i] << '-' << ev->Name() << ':'<< ev->Eval(preds_, data_sets[i]->info(), tparam.dsplit == 2);
//[99] test-auc:0.632733       test-error:0.400123     test-logloss:0.676385   
//     train-auc:0.633752      train-error:0.399833    train-logloss:0.676150		
	  }
    }
    return os.str();
  }

  std::pair<std::string, float> Evaluate(DMatrix* data, std::string metric) {
    if (metric == "auto") metric = obj_->DefaultEvalMetric();
    std::unique_ptr<Metric> ev(Metric::Create(metric.c_str()));
    this->PredictRaw(data, &preds_);
    obj_->EvalTransform(&preds_);
    return std::make_pair(metric, ev->Eval(preds_, data->info(), tparam.dsplit == 2));
  }

  void Predict(DMatrix* data,
               bool output_margin,
               std::vector<float> *out_preds,
               unsigned ntree_limit,
               bool pred_leaf) const override 
   {//实际预测
    if (pred_leaf) {
      gbm_->PredictLeaf(data, out_preds, ntree_limit);
    } else {
      this->PredictRaw(data, out_preds, ntree_limit);
      if (!output_margin) {
        obj_->PredTransform(out_preds);
      }
    }
  }

 protected:
  // check if p_train is ready to used by training.
  // if not, initialize the column access.
  inline void LazyInitDMatrix(DMatrix *p_train) 
  {//初始化数据的列方面的变量
    if (p_train->HaveColAccess()) return;//对数据只是进行一次的初始化
    int ncol = static_cast<int>(p_train->info().num_col);
	
    std::vector<bool> enabled(ncol, true);//列向量
    // set max row per batch to limited value
    // in distributed mode, use safe choice otherwise
    size_t max_row_perbatch = tparam.max_row_perbatch;
    if (tparam.test_flag == "block" || tparam.dsplit == 2) 
	{
      max_row_perbatch = std::min(static_cast<size_t>(32UL << 10UL), max_row_perbatch);
    }
    // initialize column access----完成了成员colBatchIter的初始化
    p_train->InitColAccess(enabled,//起始都是true
                           tparam.prob_buffer_row,//1
                           max_row_perbatch);//非常大
						   
    if (!p_train->SingleColBlock() && cfg_.count("updater") == 0) 
	{//pages只有一个，则不会通过
      cfg_["updater"] = "grow_histmaker,prune";
      if (gbm_.get() != nullptr) {//
        gbm_->Configure(cfg_.begin(), cfg_.end());
      }
    }
  }

  // return whether model is already initialized.
  inline bool ModelInitialized() const {
    return gbm_.get() != nullptr;
  }
 

 // lazily initialize the model if it haven't yet been initialized.
  inline void LazyInitModel() 
  {//初始化模型
    if (this->ModelInitialized()) return;//判断是否有模型
    // estimate feature bound
    unsigned num_feature = 0;
    for (size_t i = 0; i < cache_.size(); ++i)//取最大的特征数
	{
      num_feature = std::max(num_feature,
                             static_cast<unsigned>(cache_[i].mat_->info().num_col));
    }
    // run allreduce on num_feature to find the maximum value
    rabit::Allreduce<rabit::op::Max>(&num_feature, 1);
    if (num_feature > mparam.num_feature) {
      mparam.num_feature = num_feature;
    }

    // setup
    cfg_["num_feature"] = ToString(mparam.num_feature);//设置最大特征数量
    CHECK(obj_.get() == nullptr && gbm_.get() == nullptr);
	
    obj_.reset(ObjFunction::Create(name_obj_));//创建ObjFunction
	
    gbm_.reset(GradientBooster::Create(name_gbm_));//创建gbtree树
	
    gbm_->Configure(cfg_.begin(), cfg_.end());
    obj_->Configure(cfg_.begin(), cfg_.end());

    // reset the base score
    mparam.base_score = obj_->ProbToMargin(mparam.base_score);
	
	
    if (metrics_.size() == 0) {//此处两个，auc, error
      metrics_.emplace_back(Metric::Create(obj_->DefaultEvalMetric()));
    }

    this->base_score_ = mparam.base_score;//从设置偏差
    gbm_->ResetPredBuffer(pred_buffer_size_);//设置总记录数
  }
  /*!
   * \brief get un-transformed prediction---没有做变化的预测值
   * \param data training data matrix
   * \param out_preds output vector that stores the prediction
   * \param ntree_limit limit number of trees used for boosted tree
   *   predictor, when it equals 0, this means we are using all the trees
   */
  inline void PredictRaw(DMatrix* data,
                         std::vector<float>* out_preds,
                         unsigned ntree_limit = 0) const 
  {
    CHECK(gbm_.get() != nullptr)//gbm_是 GradientBooster 的指针 实际是GBTree对象
        << "Predict must happen after Load or InitModel";
		
    gbm_->Predict(data,//数据
                  this->FindBufferOffset(data),//数据的偏移量 0
                  out_preds,//预测结果存放
                  ntree_limit);//0
				  
				  
    // add base margin
    std::vector<float>& preds = *out_preds;
    const bst_omp_uint ndata = static_cast<bst_omp_uint>(preds.size());
    const std::vector<bst_float>& base_margin = data->info().base_margin;
    if (base_margin.size() != 0) 
	{
      CHECK_EQ(preds.size(), base_margin.size())
          << "base_margin.size does not match with prediction size";
      #pragma omp parallel for schedule(static)
      for (bst_omp_uint j = 0; j < ndata; ++j) {
        preds[j] += base_margin[j];
      }
    }
	else {
      #pragma omp parallel for schedule(static)
      for (bst_omp_uint j = 0; j < ndata; ++j) {//加偏移
        preds[j] += this->base_score_;
      }
    }
  }

  //xu
  void Debug()
  {
	std::cout<<"=====LearnerImpl Dubeg================" <<std::cout;  
	std::cout<<"pred_buffer_size_:" <<pred_buffer_size_<<std::cout;
	std::cout<<"mparam:" <<std::cout;
	mparam.Debug();
	
	std::cout<<"tparam:" <<std::cout;
	tparam.Debug();
	
	std::cout<<"cfg_:" <<std::cout;
	for(size_t i=0;i!=cfg_.size();i++)
		std::cout<<cfg_[i].first<<"="<<cfg_[i].second<<"#";
	std::cout<<std::cout;
	
	
	std::cout<<"name_gbm_:" <<name_gbm_<<std::cout;
	std::cout<<"name_obj_:" <<name_obj_<<std::cout;
	
	std::cout<<"preds_:"<<std::cout;
	for(size_t i=0;i!=std::min(preds_.size(),3);i++)
		std::cout<<preds_[i]<<"#";
	std::cout<<std::cout;
	
	std::cout<<"gpair_:"<<std::cout;
	for(size_t i=0;i!=std::min(gpair_.size(),3);i++)
		std::cout<<"<"<<gpair_[i].grad<<","<<gpair_[i].hess<<">"<<"#";
	std::cout<<std::cout;

	std::cout<<"static kRandSeedMagic:" <<kRandSeedMagic<<std::cout;
	
	std::cout<<"cache_:"<<std::cout;
	for(size_t i=0;i!=std::min(cache_.size(),3);i++)
		std::cout<<"{"<<cache_[i].mat_<<","<<cache_[i].buffer_offset_<<","<<cache_[i].num_row_<<"#";
	std::cout<<std::cout;
	
  }  
  
//变量区  
  
  // cached size of predict buffer         预测的缓存大小：训练记录数和预测的记录数的和
  size_t pred_buffer_size_;
  // model parameter  模型参数
  LearnerModelParam mparam;
  // training parameter 训练参数
  LearnerTrainParam tparam;
  // configurations  配置参数
  std::map<std::string, std::string> cfg_;
  // name of gbm                            模型类型： gbtree
  std::string name_gbm_;
  // name of objective functon              损失函数类型： reg:linear
  std::string name_obj_;
  // temporal storages for prediction       预测值存储
  std::vector<float> preds_;
  // gradient pairs
  std::vector<bst_gpair> gpair_;//梯度对

 private:
  /*! \brief random number transformation seed. */
  static const int kRandSeedMagic = 127;
  // cache entry object that helps handle feature caching  单个CacheEntry表示一个数据集合
  struct CacheEntry {
    const DMatrix* mat_;//数据集合的首地址
    size_t buffer_offset_;// 在全局数据中的偏移位置 （记录数的偏移）如第一个数据集合100，那么第二个数据集合的偏移是100
    size_t num_row_;// 本数据集合记录数
    CacheEntry(const DMatrix* mat, size_t buffer_offset, size_t num_row)
        :mat_(mat), buffer_offset_(buffer_offset), num_row_(num_row) {}
  };

  // find internal buffer offset for certain matrix, if not exist, return -1
  inline int64_t FindBufferOffset(const DMatrix* mat) const 
  {
    for (size_t i = 0; i < cache_.size(); ++i) {
      if (cache_[i].mat_ == mat && mat->cache_learner_ptr_ == this) {
        if (cache_[i].num_row_ == mat->info().num_row)
		{
          return static_cast<int64_t>(cache_[i].buffer_offset_);
        }
      }
    }
    return -1;
  }
  /*! \brief the entries indicates that we have internal prediction cache  存多个数据集合：测试集合+训练集合*/
  std::vector<CacheEntry> cache_;
};

Learner* Learner::Create(const std::vector<DMatrix*>& cache_data) 
{//创建
  return new LearnerImpl(cache_data);
}
}  // namespace xgboost
