Demonstrating how to use XGBoost on [Year Prediction task of Million Song Dataset](https://archive.ics.uci.edu/ml/datasets/YearPredictionMSD)

1. Run runexp.sh
```bash
./runexp.sh
```

You can also use the script to prepare LIBSVM format, and run the [Distributed Version](../../multi-node).
Note that though that normally you only need to use single machine for dataset at this scale, and use distributed version for larger scale dataset.
