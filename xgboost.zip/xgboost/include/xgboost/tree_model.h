/*!
 * Copyright 2014 by Contributors
 * \file tree_model.h
 * \brief model structure for tree
 * \author Tianqi Chen
 */
#ifndef XGBOOST_TREE_MODEL_H_
#define XGBOOST_TREE_MODEL_H_

#include <dmlc/io.h>
#include <dmlc/parameter.h>
#include <limits>
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>
#include "./base.h"
#include "./data.h"
#include "./logging.h"
#include "./feature_map.h"

namespace xgboost {

/*! \brief meta parameters of the tree */
struct TreeParam : public dmlc::Parameter<TreeParam> {
  /*! \brief number of start root 开始的根节点数，默认设置1*/
  int num_roots;
  /*! \brief total number of nodes 总节点数，默认设置1*/
  int num_nodes;
  /*!\brief number of deleted nodes 被删除的节点数 0*/
  int num_deleted;
  /*! \brief maximum depth, this is a statistics of the tree 最大的树深度 0*/
  int max_depth;
  /*! \brief number of features used for tree construction 构造树的特征数 0*/
  int num_feature;
  /*!
   * \brief leaf vector size, used for vector tree
   * used to store more than one dimensional information in tree
   */
  int size_leaf_vector;
  /*! \brief reserved part, make sure alignment works for 64bit 预留给64位的 0*/
  int reserved[31];
  /*! \brief constructor 构造函数*/
  TreeParam() {
    // assert compact alignment
    static_assert(sizeof(TreeParam) == (31 + 6) * sizeof(int),
                  "TreeParam: 64 bit align");
    std::memset(this, 0, sizeof(TreeParam));//初始化都为0
    num_nodes = num_roots = 1;//
  }
  // declare the parameters
  DMLC_DECLARE_PARAMETER(TreeParam) {
    // only declare the parameters that can be set by the user.
    // other arguments are set by the algorithm.
    DMLC_DECLARE_FIELD(num_roots).set_lower_bound(1).set_default(1)
        .describe("Number of start root of trees.");
    DMLC_DECLARE_FIELD(num_feature)
        .describe("Number of features used in tree construction.");
    DMLC_DECLARE_FIELD(size_leaf_vector).set_lower_bound(0).set_default(0)
        .describe("Size of leaf vector, reserved for vector tree");
  }
};

/*!
 * \brief template class of TreeModel
 * \tparam TSplitCond data type to indicate split condition
 * \tparam TNodeStat auxiliary statistics of node to help tree building
 */
template<typename TSplitCond, typename TNodeStat>
class TreeModel 
{
 public:
  /*! \brief data type to indicate split condition  */
  typedef TNodeStat  NodeStat;//此处是 RTreeNodeStat
  /*! \brief auxiliary statistics of node to help tree building */
  typedef TSplitCond SplitCond;//此处是 bst_float ，辅助统计去做构建树 
  /*! \brief tree node */
  class Node
  {
   public:
   //构造函数，只是初始化了分裂特征索引值
    Node() : sindex_(0) {
      // assert compact alignment  对齐方式
      static_assert(sizeof(Node) == 4 * sizeof(int) + sizeof(Info),
                    "Node: 64 bit align");//
    }
    /*! \brief index of left child */
    inline int cleft() const {//获取左儿子节点编号
      return this->cleft_;
    }
    /*! \brief index of right child */
    inline int cright() const {//右儿子
      return this->cright_;
    }
    /*! \brief index of default child when feature is missing */
    inline int cdefault() const {//缺失值流向的儿子节点编号
      return this->default_left() ? this->cleft() : this->cright();
    }
    /*! \brief feature index of split condition */
    inline unsigned split_index() const {//无方向的节点编号，即去掉最高的值
      return sindex_ & ((1U << 31) - 1U);
    }
    /*! \brief when feature is unknown, whether goes to left child */
    inline bool default_left() const {//缺失值的默认走向，最高位是1则左
      return (sindex_ >> 31) != 0;
    }
    /*! \brief whether current node is leaf node */
    inline bool is_leaf() const {//左儿子为-1时表示叶子节点
      return cleft_ == -1;
    }
    /*! \return get leaf value of leaf node */
    inline float leaf_value() const {
      return (this->info_).leaf_value;
    }
    /*! \return get split condition of the node */
    inline TSplitCond split_cond() const {
      return (this->info_).split_cond;
    }
    /*! \brief get parent of the node */
    inline int parent() const {//只取其父节点的编号，不带最高位
      return parent_ & ((1U << 31) - 1);
    }
    /*! \brief whether current node is left child */
    inline bool is_left_child() const {//判断本节点是否是左儿子，parent_最高位存放了本节点属于父节点儿子类型
      return (parent_ & (1U << 31)) != 0;
    }
    /*! \brief whether this node is deleted */
    inline bool is_deleted() const {//分裂特征索引是最大值，则表示删除
      return sindex_ == std::numeric_limits<unsigned>::max();
    }
    /*! \brief whether current node is root */
    inline bool is_root() const {
      return parent_ == -1;//此处非常佩服，直接赋值，其实质上是存了它的补码也就是实际内存的值是FF-FF-FF-FF，
						  //也就是说其实根节点是取了最大值7F-FF-FF-FF
    }
    /*!
     * \brief set the right child
     * \param nid node id to right child
     */
    inline void set_right_child(int nid) {//作为右儿子
      this->cright_ = nid;
    }
    /*!
     * \brief set split condition of current node
     * \param split_index feature index to split
     * \param split_cond  split condition
     * \param default_left the default direction when feature is unknown
     */
	 //设置分裂值
    inline void set_split(unsigned split_index, TSplitCond split_cond,bool default_left = false)
	{
      if (default_left) split_index |= (1U << 31);
      this->sindex_ = split_index;
      (this->info_).split_cond = split_cond;
    }
    /*!
     * \brief set the leaf value of the node
     * \param value leaf value
     * \param right right index, could be used to store
     *        additional information
     */
	 //无左右儿子，则设置cleft_=right=-1，注意right可以存放额外信息（设置为0）--可以用来说不是真的叶子，而是可以更新的
    inline void set_leaf(float value, int right = -1) {//done
      (this->info_).leaf_value = value;//本身的值
      this->cleft_ = -1;//左右都为-1，优先右
      this->cright_ = right;
    }
    /*! \brief mark that this node is deleted */
    inline void mark_delete() {//设置为可以删除
      this->sindex_ = std::numeric_limits<unsigned>::max();
    }

   private:
    //表示TreeModel完全访问权限
    friend class TreeModel<TSplitCond, TNodeStat>;
    /*!
     * \brief in leaf node, we have weights, in non-leaf nodes,
     *        we have split condition
     */
	 //leaf_value表示叶子节点的值，split_cond表示非叶子节点的分裂值
    union Info{
      float leaf_value;
      TSplitCond split_cond;
    };
    // pointer to parent, highest bit is used to
    // indicate whether it's a left child or not
	//父节点，包含了最高的含义，即父节点是左或者右
    int parent_;
    // pointer to left, right
	//左右节点，注意这里的值是不包含最高位的，可理解都是正值	
    int cleft_, cright_;
    // split feature index, left split or right split depends on the highest bit
    //节点的分裂特征编号值，最高位决定了缺失数据的走向，0表示右，1表示左
	unsigned sindex_;
    // extra info
	//存放了分裂节点的分裂值，若是叶子节点，则用leaf_value存值
    Info info_;
    // set parent 
	//输入父节点编号且是去掉左右特点的，is_left_child表示本节点是否是父节点的是否是左儿子
	//被设置为私有变量，表示只能被TreeModel访问
    inline void set_parent(int pidx, bool is_left_child = true) {
		
	//这次的存储由于pidx是正值，而最高位通过移位获取，故而很妙
      if (is_left_child) pidx |= (1U << 31);//判断父节点是否是左，是则设置最高位为1
      this->parent_ = pidx;
    }
  };

 protected:
  // vector of nodes 
  //树存放节点的容器
  std::vector<Node> nodes;
  // free node space, used during training process  
  //释放节点
  std::vector<int>  deleted_nodes;
  // stats of nodes 
  //节点状态，类型由模版决定，此处 RTreeNodeStat
  std::vector<TNodeStat> stats;
  // leaf vector, that is used to store additional information 
  //叶子节点向量，存放附加信息
  std::vector<bst_float> leaf_vector;
  
  
  
  // allocate a new node,
  // !!!!!! NOTE: may cause BUG here, nodes.resize
  //申请新节点的空间
  inline int AllocNode() 
  {
	//对于有待删除的节点，实际上做逻辑上的删除，没有真的释放内存，
	//返回这个逻辑被删除的点表示重新分配了
    if (param.num_deleted != 0) {//删除容器有则先删除容器节点编号
      int nd = deleted_nodes.back();
      deleted_nodes.pop_back();//删除最后一个元素
      --param.num_deleted;
      return nd;//返回最后一个被删除的节点编号，表示这个删除，可以被使用了
    }
	
	
    int nd = param.num_nodes++;
    CHECK_LT(param.num_nodes, std::numeric_limits<int>::max())//不允许超过最大值 LG表示low than小于
        << "number of nodes in the tree exceed 2^31";
	//做空间内存申请，且初始新插入值为0
/*resize详细解释如下：
oid resize (size_type n);
void resize (size_type n, value_type val);
resize函数重新分配大小，改变容器的大小，并且创建对象
当n小于当前size()值时候，vector首先会减少size()值 保存前n个元素，然后将超出n的元素删除(remove and destroy)

当n大于当前size()值时候，vector会插入相应数量的元素 使得size()值达到n，并对这些元素进行初始化，如果调用上面的第二个resize函数，指定val，vector会用val来初始化这些新插入的元素

当n大于capacity()值的时候，会自动分配重新分配内存存储空间。

顺便提一下：void reserve (size_type n);表示修改capacity值，预分配值
*/	
    nodes.resize(param.num_nodes);
    stats.resize(param.num_nodes);
    leaf_vector.resize(param.num_nodes * param.size_leaf_vector);
    return nd;
  }
  
  // delete a tree node, keep the parent field to allow trace back
  //删除节点nid，并非真的释放空间
  inline void DeleteNode(int nid) {
    CHECK_GE(nid, param.num_roots);
    deleted_nodes.push_back(nid);
    nodes[nid].mark_delete();//标记该节点被删除了
    ++param.num_deleted;
  }

 public:
  /*!
   * \brief change a non leaf node to a leaf node, delete its children
   * \param rid node id of the node
   * \param value new leaf value
   */
   //改变非叶子节点为叶子节点，前提是儿子节点是叶子节点
  inline void ChangeToLeaf(int rid, float value) {
	//表示该节点的儿子节点必须是叶子节点  
    CHECK(nodes[nodes[rid].cleft() ].is_leaf());//真才会通过
    CHECK(nodes[nodes[rid].cright()].is_leaf());
    this->DeleteNode(nodes[rid].cleft());
    this->DeleteNode(nodes[rid].cright());
    nodes[rid].set_leaf(value);
  }
  /*!
   * \brief collapse a non leaf node to a leaf node, delete its children
   * \param rid node id of the node
   * \param value new leaf value
   */
   //改变非叶子节点为叶子节点，节点没有束缚，此节点以下都被删除了
  inline void CollapseToLeaf(int rid, float value) {
    if (nodes[rid].is_leaf()) return;
    if (!nodes[nodes[rid].cleft() ].is_leaf()) {
      CollapseToLeaf(nodes[rid].cleft(), 0.0f);
    }
    if (!nodes[nodes[rid].cright() ].is_leaf()) {
      CollapseToLeaf(nodes[rid].cright(), 0.0f);
    }
    this->ChangeToLeaf(rid, value);//将其变为叶子节点
  }

 public:
  /*! \brief model parameter  */
  //树相关的参数结构体
  TreeParam param;
  
  
  /*! \brief constructor  构造函数*/
  TreeModel() {//构造节点数是1，root数1，删除节点数0，以及初始化了nodes容器
    param.num_nodes = 1;
    param.num_roots = 1;
    param.num_deleted = 0;
	
    nodes.resize(1);//resize是改变容器的大小为1，且在创建对象
  }
  /*! \brief get node given nid */
  inline Node& operator[](int nid) {//获取节点
    return nodes[nid];
  }
  /*! \brief get node given nid */
  inline const Node& operator[](int nid) const {
    return nodes[nid];
  }
  /*! \brief get node statistics given nid */
  inline NodeStat& stat(int nid) {//获取节点的状态信息
    return stats[nid];
  }
  /*! \brief get node statistics given nid */
  inline const NodeStat& stat(int nid) const {
    return stats[nid];
  }
  /*! \brief get leaf vector given nid */
  inline bst_float* leafvec(int nid) {//获取叶子节点额外信息
    if (leaf_vector.size() == 0) return nullptr;
    return& leaf_vector[nid * param.size_leaf_vector];
  }
  /*! \brief get leaf vector given nid */
  inline const bst_float* leafvec(int nid) const {
    if (leaf_vector.size() == 0) return nullptr;
    return& leaf_vector[nid * param.size_leaf_vector];
  }
  /*! \brief initialize the model 初始化model*/
  //初始化根节点为叶子节点
  inline void InitModel() {
    param.num_nodes = param.num_roots;
	
    nodes.resize(param.num_nodes);
    stats.resize(param.num_nodes);
	
	//树的叶子向量大小=节点数*单个节点叶子向量大小
    leaf_vector.resize(param.num_nodes * param.size_leaf_vector, 0.0f);//默认是0
	
    for (int i = 0; i < param.num_nodes; i ++) {
      nodes[i].set_leaf(0.0f);//初始化节点
      nodes[i].set_parent(-1);//设置根节点(BUG啊！！！明明函数是要求参数值为大于0的)
    }
  }
  /*!
   * \brief load model from stream
   * \param fi input stream
   */
  inline void Load(dmlc::Stream* fi) {
    CHECK_EQ(fi->Read(&param, sizeof(TreeParam)), sizeof(TreeParam));
    nodes.resize(param.num_nodes);
    stats.resize(param.num_nodes);
    CHECK_NE(param.num_nodes, 0);
    CHECK_EQ(fi->Read(dmlc::BeginPtr(nodes), sizeof(Node) * nodes.size()),
             sizeof(Node) * nodes.size());
    CHECK_EQ(fi->Read(dmlc::BeginPtr(stats), sizeof(NodeStat) * stats.size()),
             sizeof(NodeStat) * stats.size());
    if (param.size_leaf_vector != 0) {
      CHECK(fi->Read(&leaf_vector));
    }
    // chg deleted nodes
    deleted_nodes.resize(0);
    for (int i = param.num_roots; i < param.num_nodes; ++i) {
      if (nodes[i].is_deleted()) deleted_nodes.push_back(i);
    }
    CHECK_EQ(static_cast<int>(deleted_nodes.size()), param.num_deleted);
  }
  /*!
   * \brief save model to stream
   * \param fo output stream
   */
  inline void Save(dmlc::Stream* fo) const {
    CHECK_EQ(param.num_nodes, static_cast<int>(nodes.size()));
    CHECK_EQ(param.num_nodes, static_cast<int>(stats.size()));
    fo->Write(&param, sizeof(TreeParam));
    CHECK_NE(param.num_nodes, 0);
    fo->Write(dmlc::BeginPtr(nodes), sizeof(Node) * nodes.size());
    fo->Write(dmlc::BeginPtr(stats), sizeof(NodeStat) * nodes.size());
    if (param.size_leaf_vector != 0) fo->Write(leaf_vector);
  }
  /*!
   * \brief add child nodes to node
   * \param nid node id to add childs
   */
  inline void AddChilds(int nid) 
  {//增加儿子节点
    int pleft  = this->AllocNode();//返回节点编号
    int pright = this->AllocNode();
    nodes[nid].cleft_  = pleft;
    nodes[nid].cright_ = pright;
    nodes[nodes[nid].cleft() ].set_parent(nid, true);//设置新节点的父节点
    nodes[nodes[nid].cright()].set_parent(nid, false);
  }
  /*!
   * \brief only add a right child to a leaf node
   * \param nid node id to add right child
   */
   //只是增加右儿子
  inline void AddRightChild(int nid) {
    int pright = this->AllocNode();
    nodes[nid].right  = pright;
    nodes[nodes[nid].right].set_parent(nid, false);
  }
  /*!
   * \brief get current depth
   * \param nid node id
   * \param pass_rchild whether right child is not counted in depth
   */
   //获取到根节点的长度
   //默认是节点到根节点的路劲长度，若是设置pass_rchild为真，则长度是指前驱型长度，属于右侧边被pass了
  inline int GetDepth(int nid, bool pass_rchild = false) const {
    int depth = 0;
    while (!nodes[nid].is_root()) {//判断本节点是不是父节点
      if (!pass_rchild || nodes[nid].is_left_child()) ++depth;
      nid = nodes[nid].parent();
    }
    return depth;
  }
  /*!
   * \brief get maximum depth
   * \param nid node id
   */
   //节点nid到叶子最大深度
  inline int MaxDepth(int nid) const {
    if (nodes[nid].is_leaf()) return 0;
    return std::max(MaxDepth(nodes[nid].cleft())+1,
                     MaxDepth(nodes[nid].cright())+1);
  }
  /*!
   * \brief get maximum depth
   */
   //多颗树最深
  inline int MaxDepth() {
    int maxd = 0;
    for (int i = 0; i < param.num_roots; ++i) {
      maxd = std::max(maxd, MaxDepth(i));
    }
    return maxd;
  }
  /*! \brief number of extra nodes besides the root */
  //表示出去根节点，以及删除的节点（剪枝的），还有多少个节点
  inline int num_extra_nodes() const 
  {
    return param.num_nodes - param.num_roots - param.num_deleted;
  }
};

/*! \brief node statistics used in regression tree */
//树的节点状态信息，应用于回归树
struct RTreeNodeStat {
  /*! \brief loss change caused by current split */
  //信息增益值
  float loss_chg;
  /*! \brief sum of hessian values, used to measure coverage of data */
  //h值
  float sum_hess;
  /*! \brief weight of current node  */
  //节点权重
  float base_weight;
  /*! \brief number of child that is leaf node known up to now*/
  //此时节点的儿子数
  int leaf_child_cnt;
};

/*!
 * \brief define regression tree to be the most common tree model.
 *  This is the data structure used in xgboost's major tree models.
 */
 //树的主要模型，回归树
class RegTree: public TreeModel<bst_float, RTreeNodeStat> 
{
 public:
  /*!
   * \brief dense feature vector that can be taken by RegTree
   * and can be construct from sparse feature vector.
   */
   //特征向量，稀疏型的，一行的值
  struct FVec {
   public:
    /*!
     * \brief initialize the vector with size vector
     * \param size The size of the feature vector.
     */
	 //大小为size的特征向量--体现行数
    inline void Init(size_t size);
    /*!
     * \brief fill the vector with sparse vector
     * \param inst The sparse instance to fil.
     */
    inline void Fill(const RowBatch::Inst& inst);
    /*!
     * \brief drop the trace after fill, must be called after fill.
     * \param inst The sparse instanc to drop.
     */
    inline void Drop(const RowBatch::Inst& inst);
    /*!
     * \brief get ith value
     * \param i feature index.
     * \return the i-th feature value
     */
    inline float fvalue(size_t i) const;
    /*!
     * \brief check whether i-th entry is missing
     * \param i feature index.
     * \return whether i-th value is missing.
     */
    inline bool is_missing(size_t i) const;

   private:
    /*!
     * \brief a union value of value and flag
     *  when flag == -1, this indicate the value is missing
     */
	 //特征存储最小结构单元，采用union，flag=-1表示missing，否则就是fvalue填写值
    union Entry {//共享内存，采取大的变量作为该类型大小
      float fvalue;//这里奇特在于，若是给-1给了fvalue，
				   //由于存储方式是float，则-1不是全占，故而用flag==-1是不成立的
      int flag;
    };
    std::vector<Entry> data;
  };
  /*!
   * \brief get the leaf index
   * \param feat dense feature vector, if the feature is missing the field is set to NaN
   //稠密向量，对于缺失值是使用NAN值代替，其实就是用flag标志位-1来表示
   * \param root_id starting root index of the instance
   * \return the leaf index of the given feature
   */
   //通过样本点，获取该点所属叶子节点
  inline int GetLeafIndex(const FVec& feat, unsigned root_id = 0) const;
  /*!
   * \brief get the prediction of regression tree, only accepts dense feature vector
   * \param feat dense feature vector, if the feature is missing the field is set to NaN
   * \param root_id starting root index of the instance
   * \return the leaf index of the given feature
   */
   //样本点，获取预测值
  inline float Predict(const FVec& feat, unsigned root_id = 0) const;
  /*!
   * \brief get next position of the tree given current pid
   * \param pid Current node id.
   * \param fvalue feature value if not missing.
   * \param is_unknown Whether current required feature is missing.
   */
  inline int GetNext(int pid, float fvalue, bool is_unknown) const;
  /*!
   * \brief dump model to text string
   * \param fmap feature map of feature types
   * \param with_stats whether dump out statistics as well
   * \return the string of dumped model
   */
  std::string Dump2Text(const FeatureMap& fmap, bool with_stats) const;
};

// implementations of inline functions
// do not need to read if only use the model
//初始化特征向量，都是缺失
inline void RegTree::FVec::Init(size_t size) {
  Entry e; e.flag = -1;
  data.resize(size);
  std::fill(data.begin(), data.end(), e);
}

inline void RegTree::FVec::Fill(const RowBatch::Inst& inst) {
  for (bst_uint i = 0; i < inst.length; ++i) 
  {
    if (inst[i].index >= data.size()) continue;
    data[inst[i].index].fvalue = inst[i].fvalue;//针对特征号赋予该行的特征值
  }
}

inline void RegTree::FVec::Drop(const RowBatch::Inst& inst) {
  for (bst_uint i = 0; i < inst.length; ++i) {
    if (inst[i].index >= data.size()) continue;
    data[inst[i].index].flag = -1;//设置为缺失值
  }
}

inline float RegTree::FVec::fvalue(size_t i) const {
  return data[i].fvalue;//根据特征号返回特征值
}

inline bool RegTree::FVec::is_missing(size_t i) const {
  return data[i].flag == -1;//对某个行设置为缺失值
}


//获取叶子节点编号
inline int RegTree::GetLeafIndex(const RegTree::FVec& feat, unsigned root_id) const {
  int pid = static_cast<int>(root_id);
  while (!(*this)[pid].is_leaf()) 
  {//
    unsigned split_index = (*this)[pid].split_index();//分裂点
    pid = this->GetNext(pid, feat.fvalue(split_index), feat.is_missing(split_index));//feat.fvalue(split_index)表示了该行在这个特征的值
  }
  return pid;
}
//获取预测值
inline float RegTree::Predict(const RegTree::FVec& feat, unsigned root_id) const {
  int pid = this->GetLeafIndex(feat, root_id);
  return (*this)[pid].leaf_value();//给该叶子节点的值
}

/*! \brief get next position of the tree given current pid */
//通过当前节点获取下个节点，
inline int RegTree::GetNext(int pid, float fvalue, bool is_unknown) const 
{
  float split_value = (*this)[pid].split_cond();
  if (is_unknown) {
    return (*this)[pid].cdefault();
  } else {
    if (fvalue < split_value) {
      return (*this)[pid].cleft();
    } else {
      return (*this)[pid].cright();
    }
  }
}
}  // namespace xgboost
#endif  // XGBOOST_TREE_MODEL_H_
