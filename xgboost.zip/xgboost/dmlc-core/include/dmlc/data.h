/*!
 *  Copyright (c) 2015 by Contributors
 * \file data.h
 * \brief defines common input data structure,
 *  and interface for handling the input data
 */
#ifndef DMLC_DATA_H_
#define DMLC_DATA_H_

#include <string>
#include <vector>
#include <map>
#include "./base.h"
#include "./io.h"
#include "./logging.h"
#include "./registry.h"

namespace dmlc {
/*!
 * \brief this defines the float point
 * that will be used to store feature values
 实数类型
 */
typedef float real_t;

/*!
 * \brief this defines the unsigned integer type
 * that can normally be used to store feature index
 无符号类型
 */
typedef unsigned index_t;

// This file describes common data structure that can be used
// for large-scale machine learning, this may not be a complete list
// But we will keep the most common and useful ones, and keep adding new ones
/*!
 * \brief data iterator interface
 *  this is not a C++ style iterator, but nice for data pulling:)
 *  This interface is used to pull in the data
 *  The system can do some useful tricks for you like pre-fetching
 *  from disk and pre-computation.
 *
 * Usage example:
 * \code
 *
 *   itr->BeforeFirst();
 *   while (itr->Next()) {
 *      const DType &batch = itr->Value();
 *      // some computations
 *   }
 * \endcode
 * \tparam DType the data type
 这个接口非常适合数据的拉取，可以方便于提前拉取，从磁盘，并且能提前做运算，
 它是数据的公共接口，高度抽象的
 对于数据，只有获取数据开始位置，下一块数据，以及返回数据这3个操作
 */
template<typename DType>
class DataIter {
 public:
  /*! \brief destructor */
  //解析函数，此处是虚函数以便具体实例解析本身内存
  //不需要构造函数，因为是接口不能作为实例化使用
  //用于提供指针或引用来调用，用于不同实例共同操作
  virtual ~DataIter(void) {}
  /*! \brief set before first of the item */
  //数据开始的前一个位置
  virtual void BeforeFirst(void) = 0;
  /*! \brief move to next item */
  //移动指针到下个位置，返回该操作是否成功
  virtual bool Next(void) = 0;
  /*! \brief get current data */
  //返回接口获取的数据
  virtual const DType &Value(void) const = 0;
};

/*!
 * \brief one row of training instance
 * \tparam IndexType type of index
 行数据的存储
 */
template<typename IndexType>
class Row {//单独一行
 public:
  /*! \brief label of the instance */
  //标签值
  real_t label;//标签
  /*! \brief weight of the instance */
  //权重值
  real_t weight;//
  /*! \brief length of the sparse vector */
  //特征个数
  size_t length;
  /*!
   * \brief index of each instance
   */
   //特征号
  const IndexType *index;
  /*!
   * \brief array value of each instance, this can be NULL
   *  indicating every value is set to be 1
   */
   //特征值
  const real_t *value;
  /*!
   * \param i the input index
   * \return i-th feature
   */
   //返回特征号
  inline IndexType get_index(size_t i) const {
    return index[i];
  }
  /*!
   * \param i the input index
   * \return i-th feature value, this function is always
   *  safe even when value == NULL
   */
   //特征值
  inline real_t get_value(size_t i) const {
    return value == NULL ? 1.0f : value[i];//特征值
  }
  /*!
   * \brief helper function to compute dot product of current
   * \param weight the dense array of weight we want to product
   * \param size the size of the weight vector
   * \tparam V type of the weight vector
   * \return the result of dot product
   */
   //计算内积的函数，参数1是特征的权重向量，参数2是其长度，是特征总长度
   //根据index找到特征号，基于该特征号能够找到权重，最后做加权和，作为样本的内积值
  template<typename V>
  inline V SDot(const V *weight, size_t size) const {
    V sum = static_cast<V>(0);
    if (value == NULL) 
	{//该行没有特征
      for (size_t i = 0; i < length; ++i) {
        CHECK(index[i] < size) << "feature index exceed bound";
        sum += weight[index[i]];//累计特征权重总和
      }
    } 
	else {//有特征值
      for (size_t i = 0; i < length; ++i) {
        CHECK(index[i] < size) << "feature index exceed bound";//超出
        sum += weight[index[i]] * value[i];//求特征值的加权和
      }
    }
    return sum;
  }
};

/*!
 * \brief a block of data, containing several rows in sparse matrix
 *  This is useful for (streaming-sxtyle) algorithms that scans through rows of data
 *  examples include: SGD, GD, L-BFGS, kmeans
 *
 *  The size of batch is usually large enough so that parallelizing over the rows
 *  can give significant speedup
 * \tparam IndexType type to store the index used in row batch
 对于流的处理方便，适合并行化的数据处理结构
 */
template<typename IndexType>
struct RowBlock {
  /*! \brief batch size */
  //block的大小
  size_t size;//
  /*! \brief array[size+1], row pointer to beginning of each rows */
  //block的偏移值，大小是行数+1
  const size_t *offset;
  
  /*! \brief array[size] label of each instance */
  //行的标签值
  const real_t *label;
  
  /*! \brief With weight: array[size] label of each instance, otherwise nullptr */
  //行的权重值
  const real_t *weight;
  
  /*! \brief feature index */
  //数组指针，存放一行值的特征值
  const IndexType *index;
  
  /*! \brief feature value, can be NULL, indicating all values are 1 */
  //数组指针，存放一行特征值，若是空，则存入nullptr值与null相似（0或者(void*)0）
  const real_t *value;//特征值
  /*!
   * \brief get specific rows in the batch
   * \param rowid the rowid in that row
   * \return the instance corresponding to the row
   根据行号获取一行的值
   */
  inline Row<IndexType> operator[](size_t rowid) const;
  /*! \return memory cost of the block in bytes */
  //计算内存消耗
  inline size_t MemCostBytes(void) const {//耗内存
    size_t cost = size * (sizeof(size_t) + sizeof(real_t));//忽视了size量内存
	
    if (weight != NULL) cost += size * sizeof(real_t);//权重值内存
    size_t ndata = offset[size] - offset[0];
    if (index != NULL) cost += ndata * sizeof(IndexType);//特征号内存
    if (value != NULL) cost += ndata * sizeof(real_t);//特征值内存
    return cost;
  }
  /*!
   * \brief slice a RowBlock to get rows in [begin, end)
   * \param begin the begin row index
   * \param end the end row index
   * \return the sliced RowBlock
   将block切成片返回，体现灵活获取块中部分数据
   数据没有变化，只是返回了指针的修改，主要是偏移量的指针修改，以及权重值，标签
   */
  inline RowBlock Slice(size_t begin, size_t end) const {
    CHECK(begin <= end && end <= size);
    RowBlock ret;
    ret.size = end - begin;//大小
    ret.label = label + begin;//长度
    if (weight != NULL) {
      ret.weight = weight + begin;
    } 
	else 
	{
      ret.weight = NULL;
    }
    ret.offset = offset + begin;
    ret.index = index;
    ret.value = value;
    return ret;
  }
};

/*!
 * \brief Data structure that holds the data
 * Row block iterator interface that gets RowBlocks
 * Difference between RowBlockIter and Parser:
 *     RowBlockIter caches the data internally that can be used
 *     to iterate the dataset multiple times,
 *     Parser holds very limited internal state and was usually
 *     used to read data only once
 *
 RowBlockIter与Parser不同之处：RowBlockIter可以多次，而Parser只有一次读
 
 * \sa Parser
 * \tparam IndexType type of index in RowBlock
 *  Create function was only implemented for IndexType uint64_t and uint32_t
 IndexType的模板是为了兼容32位和64位问题
 */
template<typename IndexType>
class RowBlockIter : public DataIter<RowBlock<IndexType> > {
 public:
  /*!
   * \brief create a new instance of iterator that returns rowbatch
   *  by default, a in-memory based iterator will be returned
   *
   * \param uri the uri of the input, can contain hdfs prefix
   * \param part_index the part id of current input
   * \param num_parts total number of splits
   * \param type type of dataset can be: "libsvm", ...
   *
   * \return the created data iterator
   */
  static RowBlockIter<IndexType> *
  Create(const char *uri,
         unsigned part_index,
         unsigned num_parts,
         const char *type);
  /*! \return maximum feature dimension in the dataset */
  //返回特征维度值
  virtual size_t NumCol() const = 0;
};

/*!
 * \brief parser interface that parses input data
 * used to load dmlc data format into your own data format
 * Difference between RowBlockIter and Parser:
 *     RowBlockIter caches the data internally that can be used
 *     to iterate the dataset multiple times,
 *     Parser holds very limited internal state and was usually
 *     used to read data only once
 *
 *
 * \sa RowBlockIter
 * \tparam IndexType type of index in RowBlock
 *  Create function was only implemented for IndexType uint64_t and uint32_t
 */
template <typename IndexType>//uint32_t
class Parser : public DataIter<RowBlock<IndexType> > {
 public:
  /*!
  * \brief create a new instance of parser based on the "type"
  *
  * \param uri_ the uri of the input, can contain hdfs prefix
  * \param part_index the part id of current input
  * \param num_parts total number of splits
  * \param type type of dataset can be: "libsvm", "auto", ...
  *
  * When "auto" is passed, the type is decided by format argument string in URI.
  *
  * \return the created parser
  */
  static Parser<IndexType> *//创建
  Create(const char *uri_,
         unsigned part_index,
         unsigned num_parts,
         const char *type);
  /*! \return size of bytes read so far */
  virtual size_t BytesRead(void) const = 0;
  /*! \brief Factory type of the parser*/
  //构造Parser<IndexType>* 的工厂
  typedef Parser<IndexType>* (*Factory)
      (const std::string& path,
       const std::map<std::string, std::string>& args,
       unsigned part_index,
       unsigned num_parts);
};

/*!
 * \brief registry entry of parser factory
 * \tparam IndexType The type of index
 注册结构体定义
 */
template<typename IndexType>
struct ParserFactoryReg
    : public FunctionRegEntryBase<ParserFactoryReg<IndexType>,
                                  typename Parser<IndexType>::Factory> {};

/*!
 * \brief Register a new distributed parser to dmlc-core.
 *
 * \param IndexType The type of Batch index, can be uint32_t or uint64_t
    区分32或64位
 * \param TypeName The typename of of the data.
	数据类型名字
 * \param FactoryFunction The factory function that creates the parser.
	函数用来创建Parser的子类对象
 *
 * \begincode
 *
 *  // defin the factory function 定义工厂函数
 *  template<typename IndexType>
 *  Parser<IndexType>*
 *  CreateLibSVMParser(const char* uri, unsigned part_index, unsigned num_parts) {
 *    return new LibSVMParser(uri, part_index, num_parts);
 *  }
 *
 *  // Register it to DMLC   注册函数到DMLC中
 *  // Then we can use Parser<uint32_t>::Create(uri, part_index, num_parts, "libsvm");
 *  // to create the parser
 *       使用宏来构造
 *  DMLC_REGISTER_DATA_PARSER(uint32_t, libsvm, CreateLibSVMParser<uint32_t>);
 *  DMLC_REGISTER_DATA_PARSER(uint64_t, libsvm, CreateLibSVMParser<uint64_t>);
 *
 * \endcode
 */
#define DMLC_REGISTER_DATA_PARSER(IndexType, TypeName, FactoryFunction) \
  DMLC_REGISTRY_REGISTER(::dmlc::ParserFactoryReg<IndexType>,           \
                         ParserFactoryReg ## _ ## IndexType, TypeName)  \
  .set_body(FactoryFunction)


// implementation of operator[]
//只是调整指针位置来读取数据
template<typename IndexType>
inline Row<IndexType>
RowBlock<IndexType>::operator[](size_t rowid) const {//[]操作
  CHECK(rowid < size);//
  Row<IndexType> inst;//存行的量
  inst.label = label[rowid];//标签量
  if (weight != NULL) {
    inst.weight = weight[rowid];
  } else {
    inst.weight = 1.0f;//没有提供，则样本权重是1
  }
  inst.length = offset[rowid + 1] - offset[rowid];//特征长度
  inst.index = index + offset[rowid];//根据偏移量得到行的位置
  if (value == NULL) {//没有特征
    inst.value = NULL;
  } else 
  {//有
    inst.value = value + offset[rowid];
  }
  return inst;
}

}  // namespace dmlc
#endif  // DMLC_DATA_H_
