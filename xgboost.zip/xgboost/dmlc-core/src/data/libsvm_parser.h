/*!
 *  Copyright (c) 2015 by Contributors
 * \file libsvm_parser.h
 * \brief iterator parser to parse libsvm format
 * \author Tianqi Chen
 */
#ifndef DMLC_DATA_LIBSVM_PARSER_H_
#define DMLC_DATA_LIBSVM_PARSER_H_

#include <dmlc/data.h>
#include <cstring>
#include "./row_block.h"
#include "./text_parser.h"
#include "./strtonum.h"

namespace dmlc {
namespace data {
/*!
 * \brief Text parser that parses the input lines
 * and returns rows in input data
 */
template <typename IndexType>
class LibSVMParser : public TextParserBase<IndexType> {
 public:
  explicit LibSVMParser(InputSplit *source, int nthread): TextParserBase<IndexType>(source, nthread) {}

 protected:
  virtual void ParseBlock(char *begin,
                          char *end,
                          RowBlockContainer<IndexType> *out);
};

template <typename IndexType>
void LibSVMParser<IndexType>::ParseBlock(char *begin,
           char *end,
           RowBlockContainer<IndexType> *out) 
{
  out->Clear();
  char * lbegin = begin;//行的开始
  char * lend = lbegin;
  while (lbegin != end) 
  {
//开头：label:weight  或者 label 
    // get line end
    lend = lbegin + 1;//获取行的结束点
    while (lend != end && *lend != '\n' && *lend != '\r') ++lend;//查找，直到获取一行
    
	// parse label[:weight]
    const char * p = lbegin;//行的开始
    const char * q = NULL;
    real_t label;
    real_t weight;
	
    int r = ParsePair<real_t, real_t>(p, lend, &q, label, weight);//获取的是行  label:weight
	
    if (r < 1) 
	{//空行
      // empty line
      lbegin = lend;//下一行
      continue;
    }
    if (r == 2)
	{//有权重
      // has weight
      out->weight.push_back(weight);//加载权重
    }
	
    if (out->label.size() != 0) 
	{
      out->offset.push_back(out->index.size());//增加偏移量
    }	
    out->label.push_back(label);//只有lable值
	
//后续的部分	
    // parse feature[:value]
    p = q;
    while (p != lend) 
	{//特征值解析
      IndexType featureId;
      real_t value;
      int r = ParsePair<IndexType, real_t>(p, lend, &q, featureId, value);
      if (r < 1) {
        p = q;
        continue;
      }
      out->index.push_back(featureId);
      if (r == 2) {//有value值
        // has value
        out->value.push_back(value);
      }
      p = q;
    }
	
	
	
    // next line
    lbegin = lend;
  }
  if (out->label.size() != 0) {
    out->offset.push_back(out->index.size());
  }
  CHECK(out->label.size() + 1 == out->offset.size());
}

}  // namespace data
}  // namespace dmlc
#endif  // DMLC_DATA_LIBSVM_PARSER_H_
